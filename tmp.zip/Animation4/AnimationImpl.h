struct ASample
{
	double time;
	DirectX::XMFLOAT4 payload;
	ASample(double t, float x, float y, float z, float w)
	{
		time = t;
		payload.x = x;
		payload.y = y;
		payload.z = z;
		payload.w = w;
	}
};

struct JointSamples
{
	std::vector<ASample> X[3]; //s r t
	DirectX::XMFLOAT4 Y[3]; //s r t
	unsigned int Z[3]; //currentSampleIndex

	JointSamples()
	{
		resetSampleIndex();
	}

	void resetSampleIndex()
	{
		Z[0] = Z[1] = Z[2] = 0;
	}

	void set(SimpleMath::Matrix matrix)
	{
		DirectX::XMVECTOR S, Q, T;
		DirectX::FXMMATRIX M = matrix;
		if (!XMMatrixDecompose(&S, &Q, &T, M))
		{
			throw "JointSamples set failed (XMMatrixDecompose return false)";
		}
		Y[0] = SimpleMath::Vector4(S);
		Y[1] = SimpleMath::Vector4(Q);
		Y[2] = SimpleMath::Vector4(T);
	}

	void append(unsigned int payloadtype, double time, float x, float y, float z, float w)
	{
		X[payloadtype].push_back(ASample(time, x, y, z, w));
	}
	void appendScaling(double t, float x, float y, float z)
	{
		append(0, t, x, y, z, .0);
	}
	void appendRotation(double t, float x, float y, float z, float w)
	{
		append(1, t, x, y, z, w);
	}
	void appendTranslation(double t, float x, float y, float z)
	{
		append(2, t, x, y, z, .0);
	}

	bool IsEmpty()
	{
		return (!X[0].size() && !X[1].size() && !X[2].size());
	}
private:
	struct AKeyPair {
		DirectX::XMFLOAT4 first;
		DirectX::XMFLOAT4 second;
		double t;
	};
	AKeyPair _getSample(unsigned int payload, double time)
	{
		auto & key = Z[payload];
		auto & x = X[payload];
		for (; key < x.size() && x[key].time < time; key++){};
		if (key == x.size())
		{
			throw "framePayload out of duration";
		}
		else if (time != x[key].time)
		{
			key--;
			//interpolation between two frames
			auto & firstKey = x[key];
			auto & secondKey = x[key + 1];
			AKeyPair keys = { firstKey.payload, secondKey.payload, (time - firstKey.time) / (secondKey.time - firstKey.time) };
			return keys;
		}
		else if (time == x[key].time)
		{
			auto & firstKey = x[key];
			AKeyPair keys = { firstKey.payload, DirectX::XMFLOAT4(), 0.0 };
			return keys;
		}
	}
public:
	void getJoint( JointSQT & joint)
	{
		joint[0] = Y[0];
		joint[1] = Y[1];
		joint[2] = Y[2];
	}
	void getJoint(double time, JointSQT & joint)
	{
		if (IsEmpty())
		{
			getJoint(joint);
		}
		else
		{
			AKeyPair keys0 = _getSample(0, time);
			joint[0] = SimpleMath::Vector4::Lerp(keys0.first, keys0.second, keys0.t);
			AKeyPair keys1 = _getSample(1, time);
			joint[1] = SimpleMath::Quaternion::Lerp(keys1.first, keys1.second, keys1.t);
			AKeyPair keys2 = _getSample(2, time);
			joint[2] = SimpleMath::Vector4::Lerp(keys2.first, keys2.second, keys2.t);
		}
	}
};
struct AnimationRep
{
	double local_duration;

	double global_time;

	double Rate;

	double global_duration;

	bool looped;

	bool playing;

	AnimationRep()
	{
		looped = true;

		playing = true;

		global_time = 0.0;
	}
};
struct AnimationRep2 : AnimationRep
{
	int loop_counter;

	SimpleMath::Vector3 prev_translation;

	SimpleMath::Vector3 begin_translation;

	SimpleMath::Vector3 end_translation;

	SimpleMath::Vector3 delta_translation;

	std::vector< JointSamples > JointsSamples;

	AnimationRep2()
	{
		loop_counter = 0;
	}
};
struct AnimationRep3 : AnimationRep
{
	Animation* animation1;

	Animation* animation2;

	std::function<double __cdecl(double, double)> BlendFunction;

	std::function<std::pair<SimpleMath::Vector3, SimpleMath::Vector3> __cdecl(double, Animation*, Animation*)> AdvanseFunction;
};