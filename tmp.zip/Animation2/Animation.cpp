#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

// #include <assimp/Importer.hpp>      // C++ importer interface
// #include <assimp/scene.h>           // Output data structure
// #include <assimp/postprocess.h>     // Post processing flags

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags

struct Animation2 : public Animation
{
	void advanseAnimation(double elapsedTime, SimpleMath::Vector3 & deltaTranslation, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
	{
		SimpleMath::Vector3 current_translation;

		double local_time = Impl->Rate * Impl->global_time;

		for (int i = 0; i < Impl->FramesTransformations.size(); i++)
		{
			auto & transform = Impl->FramesTransformations[i];
			auto & keys = Impl->FramesKeys[i];
			if (!keys.IsEmpty())
			{
				auto S = SimpleMath::Matrix::CreateScale(keys.scaling(local_time));
				auto R = SimpleMath::Matrix::CreateFromQuaternion(keys.rotation(local_time));
				if (i == 64){
					current_translation = keys.translation(local_time);
					*(getSkeletMatrix(i)) = S * R;
				}
				else{
					auto T = SimpleMath::Matrix::CreateTranslation(keys.translation(local_time));
					*(getSkeletMatrix(i)) = S * R * T;
				}
			}
			else
			{
				*(getSkeletMatrix(i)) = transform;
			}
		}

		{
			SimpleMath::Vector3 delta;
			if (Impl->loop_counter){
				delta = Impl->end_translation - Impl->prev_translation;
				Impl->loop_counter--;
				if (Impl->loop_counter)
					delta += Impl->loop_counter * Impl->delta_translation;
				delta += current_translation - Impl->begin_translation;
			}
			else
			{
				delta = current_translation - Impl->prev_translation;
			}
			deltaTranslation = delta;
		}

		Impl->prev_translation = current_translation;

		if (Impl->playing){
			Impl->loop_counter = 0;
			Impl->global_time += elapsedTime;
			if (Impl->global_time > Impl->global_duration){
				if (Impl->looped){
					double loop = Impl->global_time / Impl->global_duration;
					int trunc_loop = loop;
					Impl->loop_counter = trunc_loop;
					Impl->global_time = (loop - trunc_loop) * Impl->global_duration;
					resetFramesKeys();
				}
				else{
					Impl->global_time -= elapsedTime;
					Impl->playing = false;
				}
			}
		}
	};
};

SimpleMath::Matrix aiMatrixToSimpleMathMatrix(const aiMatrix4x4& aiMe);

void collectBones(aiNode * node, std::vector<SimpleMath::Matrix> * FramesTransformations, std::map<std::string, unsigned int> * FramesNamesIndex)
{
	for (int i = 0; i < node->mNumChildren; i++)
	{
		//get Childeren node 
		auto ChildrenNode = node->mChildren[i];

		auto pFrameIndex = FramesNamesIndex->find(ChildrenNode->mName.C_Str());
		if (pFrameIndex == FramesNamesIndex->end())
		{
			throw "";
		}

		(*FramesTransformations)[pFrameIndex->second] = aiMatrixToSimpleMathMatrix(ChildrenNode->mTransformation);

		// deeper and deeper
		collectBones(ChildrenNode, FramesTransformations, FramesNamesIndex);
	}
}

Animation* loadAnimation(const char * path, std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	Assimp::Importer importer;

	const aiScene* scene = importer.ReadFile(path, aiProcess_ConvertToLeftHanded);

	auto ret = new Animation2();

	double mDuration = scene->mAnimations[0]->mDuration;

	ret->initAnimation(FramesNamesIndex.size(), 1.0, 1.0, getSkeletMatrix);

	{
		auto pFrameIndex = FramesNamesIndex.find(scene->mRootNode->mName.C_Str());
		if (pFrameIndex == FramesNamesIndex.end())
		{
			throw "";
		}
		ret->Impl->FramesTransformations[pFrameIndex->second] = aiMatrixToSimpleMathMatrix(scene->mRootNode->mTransformation);
		collectBones(scene->mRootNode, &(ret->Impl->FramesTransformations), &FramesNamesIndex);
	}

	for (int i = 0; i < scene->mAnimations[0]->mNumChannels; i++)
	{
		auto c = scene->mAnimations[0]->mChannels[i];

		auto name = std::string(c->mNodeName.C_Str());

		auto f = FramesNamesIndex.find(name);
		if (f == FramesNamesIndex.end())
		{
			throw "";
		}
		unsigned int index = f->second;

		for (int j = 0; j < c->mNumScalingKeys; j++)
		{
			auto & s = c->mScalingKeys[j];

			ret->Impl->FramesKeys[index].appendScaling(s.mTime / mDuration, s.mValue.x, s.mValue.y, s.mValue.z);
		}

		for (int j = 0; j < c->mNumRotationKeys; j++)
		{
			auto & r = c->mRotationKeys[j];

			ret->Impl->FramesKeys[index].appendRotation(r.mTime / mDuration, r.mValue.x, r.mValue.y, r.mValue.z, r.mValue.w);
		}

		for (int j = 0; j < c->mNumPositionKeys; j++)
		{
			auto & t = c->mPositionKeys[j];

			ret->Impl->FramesKeys[index].appendTranslation(t.mTime / mDuration, t.mValue.x, t.mValue.y, t.mValue.z);
		}
	}

	auto & translate_keys = ret->Impl->FramesKeys[64].X[2];

	auto begin_translation = translate_keys[0].payload;

	auto end_translation = translate_keys[translate_keys.size() - 1].payload;

	ret->Impl->begin_translation = SimpleMath::Vector3(begin_translation.x, begin_translation.y, begin_translation.z);
	
	ret->Impl->end_translation = SimpleMath::Vector3(end_translation.x, end_translation.y, end_translation.z);
	
	ret->Impl->delta_translation = ret->Impl->end_translation - ret->Impl->begin_translation;

	ret->Impl->prev_translation = ret->Impl->begin_translation;

	return ret;
}

Animation* loadIdleAnimation(std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	return loadAnimation("Media\\Animations\\Idle.dae", FramesNamesIndex, getSkeletMatrix);
}

Animation* loadWalkingAnimation(std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	return loadAnimation("Media\\Animations\\Walking.dae", FramesNamesIndex, getSkeletMatrix);
}
