#include "main.h"

#include "DXUTgui.h"
#include "SDKmisc.h"

extern float ViewPortWidth;

extern float ViewPortHeight;

extern GraphicResources * G;

extern SwapChainGraphicResources * SCG;

extern SceneState scene_state;

extern PostProccessState post_proccess_state;

extern BoneToModelPalite bone_to_model_palite;

extern CDXUTTextHelper*                    g_pTxtHelper;

extern Character* Eve;

ID3D11ShaderResourceView* null[] = { nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr };

const float PI = 3.141592653589793238462643383279;
std::map<std::string, DirectX::XMFLOAT4X4> WorldTransforms;
const float clearColor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

bool ScanEnable = false;
bool ScanFreeze = false;

//exports
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void set_scene_world_matrix_into_camera_origin();
void set_ground_world_matrix(SimpleMath::Matrix & w);
void set_box_world_matrix(SimpleMath::Matrix & w);
void set_winstons_barrier_world_matrix(SimpleMath::Matrix & w);
void set_eve_world_matrix(SimpleMath::Matrix & w);
void set_bone_to_model_palite_transforms(SimpleMath::Matrix * p);

inline void set_scene_constant_buffer(ID3D11DeviceContext* context){
	G->scene_constant_buffer->SetData(context, scene_state);
};
inline void set_post_proccess_constant_buffer(ID3D11DeviceContext* context){
	G->post_proccess_constant_buffer->SetData(context, post_proccess_state);
};
inline void set_bone_to_model_palite_constant_buffer(ID3D11DeviceContext* context){
	G->bone_to_model_constant_buffer->SetData(context, bone_to_model_palite);
}
void DrawQuad(ID3D11DeviceContext* pd3dImmediateContext, _In_ IEffect* effect,
	_In_opt_ std::function<void __cdecl()> setCustomState);

//movement
///////////////////////////////////////////////////////////////////////////////////////////////////////////
SimpleMath::Vector3 actorForward;
SimpleMath::Vector3 actorRight;
SimpleMath::Vector3 actorPos(0, 4, -40);

void updateOrientation(SimpleMath::Vector3 cameraDirection, SimpleMath::Vector3& _cameraPos, SimpleMath::Vector3& _cameraTarget){
	auto cameraTarget = actorPos + cameraDirection;

	actorForward = cameraDirection;

	actorRight = SimpleMath::Vector3(0, 1, 0).Cross(cameraDirection);

	_cameraPos = actorPos;
	_cameraTarget = cameraTarget;
}

void updatePosition(float fElapsedTime, SimpleMath::Vector2 move){
	actorPos += fElapsedTime * 1750 * (move.x*actorForward + move.y*actorRight);

	if (ScanEnable && !ScanFreeze)
	{
		post_proccess_state.ScanDistance += fElapsedTime*15;
	}
}

//input
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void re�eiveKeyBoardInput(bool scanWorld, bool freeze){
	if (freeze){
		ScanFreeze = !ScanFreeze;
	}
	if (scanWorld){
		ScanEnable = true;
		ScanFreeze = false;
		post_proccess_state.ScanDistance = 0.0f;
	}
}

//helpers
///////////////////////////////////////////////////////////////////////////////////////////////////////////
void RenderText()
{
	g_pTxtHelper->Begin();
	g_pTxtHelper->SetInsertionPos(2, 0);
	g_pTxtHelper->SetForegroundColor(D3DXCOLOR(1.0f, 1.0f, 0.0f, 1.0f));
	g_pTxtHelper->DrawTextLine(DXUTGetFrameStats(true && DXUTIsVsyncEnabled()));
	g_pTxtHelper->DrawTextLine(DXUTGetDeviceStats());

	g_pTxtHelper->End();
}

void clearAndSetRenderTarget(ID3D11DeviceContext* context, const float ClearColor[], int n, ID3D11RenderTargetView** pRTV, ID3D11DepthStencilView* pDSV){
	for (int i = 0; i < n; i++)
		context->ClearRenderTargetView(pRTV[i], ClearColor);

	if (pDSV)
		context->ClearDepthStencilView(pDSV, D3D11_CLEAR_DEPTH, 1.0f, 0);

	context->OMSetRenderTargets(n, pRTV, pDSV);
}

void setViewPort(ID3D11DeviceContext* context, float x1 = 0, float y1 = 0, float Width = 0, float Height = 0){
	D3D11_VIEWPORT vp;
	vp.TopLeftX = 0;
	vp.TopLeftY = 0;
	vp.Width = Width == 0 ? ViewPortWidth : Width;
	vp.Height = Height == 0 ? ViewPortHeight : Height;
	vp.MinDepth = 0;
	vp.MaxDepth = 1;
	context->RSSetViewports(1, &vp);
}

//OnFrame
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OnRenderGlowObject(ID3D11DeviceContext* context, double fTime, float fElapsedTime);
void OnProccessGlow(ID3D11DeviceContext* context, double fTime, float fElapsedTime);
void OnRenderScene(ID3D11DeviceContext* context, double fTime, float fElapsedTime);
void PostProccess(ID3D11DeviceContext* context);

void CALLBACK OnFrameMove(double fTime, float fElapsedTime, void* pUserContext)
{
	using namespace SimpleMath;

	Camera::OnFrameMove(fTime, fElapsedTime, pUserContext);

	scene_state.vTime.x = fTime*0.3f;
	WorldTransforms["box"] = Matrix::CreateScale(10, 15, 5) * Matrix::CreateRotationX((PI * 11.0) / 180.0) * Matrix::CreateTranslation(-5, 0, -5);
	WorldTransforms["barrier"] = Matrix::CreateScale(20, 20, 20) * Matrix::CreateTranslation(-8, 8, 8);
	WorldTransforms["eve"] = Matrix::CreateScale(5, 5, 5) * Matrix::CreateTranslation(0, 0, -20);
}

void CALLBACK OnD3D11FrameRender(ID3D11Device* pd3dDevice, ID3D11DeviceContext* context,
	double fTime, float fElapsedTime, void* pUserContext)
{
	using namespace SimpleMath;

	{
		context->GSSetConstantBuffers(0, 1, constantBuffersToArray(*(G->scene_constant_buffer)));

		context->VSSetConstantBuffers(0, 1, constantBuffersToArray(*(G->scene_constant_buffer)));

		context->VSSetConstantBuffers(1, 1, constantBuffersToArray(*(G->bone_to_model_constant_buffer)));

		context->PSSetSamplers(0, 1, samplerStateToArray(G->render_states->AnisotropicWrap()));

		context->PSSetSamplers(1, 1, samplerStateToArray(G->render_states->PointClamp()));

		context->PSSetShaderResources(0, 8, null);
	}

	OnRenderGlowObject(context, fTime, fElapsedTime);

	OnProccessGlow(context, fTime, fElapsedTime);

	OnRenderScene(context, fTime, fElapsedTime);

	PostProccess(context);

	RenderText();
}

void OnRenderGlowObject(ID3D11DeviceContext* context, double fTime, float fElapsedTime)
{
	using namespace SimpleMath;

	setViewPort(context);
	clearAndSetRenderTarget(context, clearColor, 1, renderTargetViewToArray(SCG->RT_glowObjects.Get()), DXUTGetD3D11DepthStencilView());

	///render box
	set_box_world_matrix(Matrix(WorldTransforms["box"]));
	set_scene_constant_buffer(context);
	DrawQuad(context, G->box_glow_effect.get(), [=]{
		context->RSSetState(G->render_states->CullCounterClockwise());
	});

	//down size
	setViewPort(context, 0, 0, int(ViewPortWidth) / 2, int(ViewPortHeight) / 2);
	clearAndSetRenderTarget(context, clearColor, 1, renderTargetViewToArray(SCG->RT_glowBlurObjects.Get()), 0);

	DrawQuad(context, G->copy_effect.get(), [=]{
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(SCG->SR_glowObjects.Get()));
		context->RSSetState(G->render_states->CullNone());
		context->OMSetDepthStencilState(G->render_states->DepthNone(), 0);
	});

	//D3DX11SaveTextureToFile(context, SCG->T_glowBlurObjects.Get(), D3DX11_IFF_DDS, L"glowBlurObjects.dds");
}

void OnProccessGlow(ID3D11DeviceContext* context, double fTime, float fElapsedTime)
{
	using namespace SimpleMath;

	context->PSSetSamplers(0, 1, samplerStateToArray(G->render_states->AnisotropicClamp()));

	setViewPort(context, 0, 0, int(ViewPortWidth) / 2, int(ViewPortHeight) / 2);
	clearAndSetRenderTarget(context, clearColor, 1, renderTargetViewToArray(SCG->RT_glowBlurObjects1.Get()), 0);

	///blur
	set_scene_constant_buffer(context);
	DrawQuad(context, G->blur_horizontal_effect.get(), [=]{
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(SCG->SR_glowBlurObjects.Get()));
		context->RSSetState(G->render_states->CullNone());
		context->OMSetDepthStencilState(G->render_states->DepthNone(), 0);
	});

	context->PSSetShaderResources(3, 1, null);
	clearAndSetRenderTarget(context, clearColor, 1, renderTargetViewToArray(SCG->RT_glowBlurObjects.Get()), 0);

	set_scene_constant_buffer(context);
	DrawQuad(context, G->blur_vertical_effect.get(), [=]{
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(SCG->SR_glowBlurObjects1.Get()));
		context->RSSetState(G->render_states->CullNone());
		context->OMSetDepthStencilState(G->render_states->DepthNone(), 0);
	});

	context->PSSetSamplers(0, 1, samplerStateToArray(G->render_states->AnisotropicWrap()));
}

void OnRenderScene(ID3D11DeviceContext* context, double fTime, float fElapsedTime)
{
	using namespace SimpleMath;

	setViewPort(context);
	clearAndSetRenderTarget(context, clearColor, 1, renderTargetViewToArray(SCG->RT_scene.Get()), SCG->DS_depth.Get());

	///render sky sphere
	set_scene_world_matrix_into_camera_origin();
	set_scene_constant_buffer(context);
	G->sphere_model->Draw(G->sky_effect.get(), G->sphere_input_layout.Get(), false, false, [=]{
		context->PSSetShaderResources(2, 1, shaderResourceViewToArray(G->sky_cube_texture.Get()));

		context->RSSetState(G->render_states->CullClockwise());
	});

	///render ground
	set_ground_world_matrix(Matrix::CreateTranslation(-0.5, -0.5, 0) * Matrix::CreateScale(5000, 5000, 5000) * Matrix::CreateRotationX(PI/2.0));
	set_scene_constant_buffer(context);
	DrawQuad(context, G->ground_effect.get(), [=]{
		context->PSSetShaderResources(1, 1, shaderResourceViewToArray(G->ground_normal_texture.Get()));
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(G->ground_texture.Get()));

		context->RSSetState(G->render_states->CullNone());
	});

	///render box
	set_box_world_matrix(Matrix(WorldTransforms["box"]));
	set_scene_constant_buffer(context);
	DrawQuad(context, G->box_effect.get(), [=]{
		context->RSSetState(G->render_states->CullCounterClockwise());
	});

	///render eve
	set_eve_world_matrix(Matrix(WorldTransforms["eve"]));
	set_scene_constant_buffer(context);
	{
		advanseAnimation(fTime, fElapsedTime, -1.0f, Eve->skelet, Eve->animation);
		calculateFramesTransformations(Eve->frame, Matrix::Identity);
	}
	set_bone_to_model_palite_transforms(calculateAnimationPalite(Eve->skelet));
	set_bone_to_model_palite_constant_buffer(context);
	drawFrames(Eve->frame, context, G->eve_effect.get(), G->eve_input_layout.Get(), [=]{
		context->PSSetShaderResources(1, 1, shaderResourceViewToArray(G->eve_n_texture.Get()));
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(G->eve_d_texture.Get()));

		context->RSSetState(G->render_states->CullCounterClockwise());
	});

	//copy depth 
	context->CopyResource(SCG->T_depth1.Get(), SCG->T_depth.Get());

	//render Winston's Barrier
	set_winstons_barrier_world_matrix(Matrix(WorldTransforms["barrier"]));
 	set_scene_constant_buffer(context);
	G->sphere_model->Draw(G->winstons_barrier_effect.get(), G->sphere_input_layout.Get(), false, false, [=]{
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(G->hexagon_texture.Get()));
		context->PSSetShaderResources(6, 1, shaderResourceViewToArray(SCG->SR_depth1.Get()));
		context->OMSetBlendState(G->AdditiveBlend.Get(), Colors::Black, 0xFFFFFFFF);

		context->RSSetState(G->render_states->CullClockwise());
	});
	G->sphere_model->Draw(G->winstons_barrier_effect.get(), G->sphere_input_layout.Get(), false, false, [=]{
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(G->hexagon_texture.Get()));
		context->PSSetShaderResources(6, 1, shaderResourceViewToArray(SCG->SR_depth1.Get()));
		context->OMSetBlendState(G->AdditiveBlend.Get(), Colors::Black, 0xFFFFFFFF);

		context->RSSetState(G->render_states->CullCounterClockwise());
	});
}

void PostProccess(ID3D11DeviceContext* context)
{
	context->PSSetConstantBuffers(1, 1, constantBuffersToArray(*(G->post_proccess_constant_buffer)));

	context->PSSetSamplers(0, 1, samplerStateToArray(G->render_states->AnisotropicClamp()));

	setViewPort(context);
	clearAndSetRenderTarget(context, clearColor, 1, renderTargetViewToArray(DXUTGetD3D11RenderTargetView()), 0);

	set_post_proccess_constant_buffer(context);
	DrawQuad(context, G->post_proccess_effect.get(), [=]{
		context->PSSetShaderResources(3, 1, shaderResourceViewToArray(SCG->SR_glowObjects.Get()));
		context->PSSetShaderResources(4, 1, shaderResourceViewToArray(SCG->SR_glowBlurObjects.Get()));
		context->PSSetShaderResources(5, 1, shaderResourceViewToArray(SCG->SR_scene.Get()));
		context->PSSetShaderResources(6, 1, shaderResourceViewToArray(SCG->SR_depth.Get()));

		context->RSSetState(G->render_states->CullNone());
		context->OMSetDepthStencilState(G->render_states->DepthNone(), 0);
	});

	context->PSSetSamplers(0, 1, samplerStateToArray(G->render_states->AnisotropicWrap()));
}