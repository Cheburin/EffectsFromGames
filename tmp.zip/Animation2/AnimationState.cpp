#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

// #include <assimp/Importer.hpp>      // C++ importer interface
// #include <assimp/scene.h>           // Output data structure
// #include <assimp/postprocess.h>     // Post processing flags

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags


struct AnimationStateMachine
{
	AnimationState state;
	std::map<AnimationState, Animation *> animations;
	CharacterSkelet * skelet;

	~AnimationStateMachine(){
		for (auto p = animations.begin(); p != animations.end(); p++)
			delete (*p).second;
	}
	AnimationStateMachine(std::map<AnimationState, Animation *>  newAnimations, CharacterSkelet * newSkelet){
		state = AnimationState::idle;
		animations = newAnimations;
		skelet = newSkelet;
	}
	void exec(AnimationState newState, double newElipsedTime, SimpleMath::Vector3 & deltaTranslation){
		if (state == AnimationState::idle && newState == AnimationState::walking)
		{
			advanseAnimation(newElipsedTime, deltaTranslation, skelet, animations[state]);
			state = newState;
		}
		else if (state == AnimationState::walking && newState == AnimationState::idle)
		{
			advanseAnimation(newElipsedTime, deltaTranslation, skelet, animations[state]);
			state = newState;
		}
		else
		{
			advanseAnimation(newElipsedTime, deltaTranslation, skelet, animations[state]);
		}
	}
};

AnimationStateMachine * makeAnimationStateMachine(std::map<AnimationState, Animation *> newAnimations, CharacterSkelet * skelet)
{
	return new AnimationStateMachine(newAnimations, skelet);
}

void animationStateMachineExec(AnimationStateMachine* stateMachine, AnimationState newState, double newElipsedTime, SimpleMath::Vector3 & deltaTranslation)
{
	stateMachine->exec(newState, newElipsedTime, deltaTranslation);
}

void disposeAnimationStateMachine(AnimationStateMachine* stateMachine)
{
	delete stateMachine;
}