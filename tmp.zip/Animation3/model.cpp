#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

// #include <assimp/Importer.hpp>      // C++ importer interface
// #include <assimp/scene.h>           // Output data structure
// #include <assimp/postprocess.h>     // Post processing flags

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SimpleMath::Matrix aiMatrixToSimpleMathMatrix(const aiMatrix4x4& aiMe){
	XMFLOAT4X4 output;

	output._11 = aiMe.a1;
	output._12 = aiMe.a2;
	output._13 = aiMe.a3;
	output._14 = aiMe.a4;

	output._21 = aiMe.b1;
	output._22 = aiMe.b2;
	output._23 = aiMe.b3;
	output._24 = aiMe.b4;

	output._31 = aiMe.c1;
	output._32 = aiMe.c2;
	output._33 = aiMe.c3;
	output._34 = aiMe.c4;

	output._41 = aiMe.d1;
	output._42 = aiMe.d2;
	output._43 = aiMe.d3;
	output._44 = aiMe.d4;

	SimpleMath::Matrix ret = output;
	
	return ret.Transpose();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template<typename T>
void CreateBuffer(_In_ ID3D11Device* device, T const& data, D3D11_BIND_FLAG bindFlags, _Outptr_ ID3D11Buffer** pBuffer)
{
	assert(pBuffer != 0);

	D3D11_BUFFER_DESC bufferDesc = { 0 };

	bufferDesc.ByteWidth = (UINT)data.size() * sizeof(T::value_type);
	bufferDesc.BindFlags = bindFlags;
	bufferDesc.Usage = D3D11_USAGE_DEFAULT;

	D3D11_SUBRESOURCE_DATA dataDesc = { 0 };

	dataDesc.pSysMem = data.data();

	device->CreateBuffer(&bufferDesc, &dataDesc, pBuffer);

	//SetDebugObjectName(*pBuffer, "DirectXTK:GeometricPrimitive");
}
struct VertexPositionNormalTangentColorTextureSkinning2 : public VertexPositionNormalTangentColorTexture
{
	uint32_t indices;
	DirectX::XMFLOAT4 weights;

 	uint32_t indices2;
	DirectX::XMFLOAT4 weights2;

 	VertexPositionNormalTangentColorTextureSkinning2() 
 	{
		SetBlendIndices(XMUINT4(0, 0, 0, 0));
		SetBlendWeights(FXMVECTOR());

		SetBlendIndices2(XMUINT4(0,0,0,0));
 		SetBlendWeights2(FXMVECTOR());
	}

	void SetBlendIndices(XMUINT4 const& iindices)
	{
		this->indices = ((iindices.w & 0xff) << 24) | ((iindices.z & 0xff) << 16) | ((iindices.y & 0xff) << 8) | (iindices.x & 0xff);
	}

	void SetBlendIndices2(XMUINT4 const& iindices)
	{
 		this->indices2 = ((iindices.w & 0xff) << 24) | ((iindices.z & 0xff) << 16) | ((iindices.y & 0xff) << 8) | (iindices.x & 0xff); 
    }
	
	void SetBlendWeights(FXMVECTOR iweights)
	{
		this->weights = SimpleMath::Vector4(iweights);
		//DirectX::PackedVector::XMUBYTEN4 packed;
		//DirectX::PackedVector::XMStoreUByteN4(&packed, iweights);
		//this->weights2 = packed.v;
	}

	void SetBlendWeights2(FXMVECTOR iweights)
	{
		this->weights2 = SimpleMath::Vector4(iweights);
		//DirectX::PackedVector::XMUBYTEN4 packed;
		//DirectX::PackedVector::XMStoreUByteN4(&packed, iweights);
		//this->weights2 = packed.v;
	}
};

D3D11_INPUT_ELEMENT_DESC CharacterInputElements[9] =
{
	{ "SV_Position", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "TANGENT", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "COLOR", 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "BLENDINDICES", 0, DXGI_FORMAT_R8G8B8A8_UINT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "BLENDWEIGHT", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "BLENDINDICES", 1, DXGI_FORMAT_R8G8B8A8_UINT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
	{ "BLENDWEIGHT", 1, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
};

DirectX::ModelMeshPart* CreateModelMeshPart(ID3D11Device* device, std::function<void(std::vector<VertexPositionNormalTangentColorTextureSkinning2> & _vertices, std::vector<UINT> & _indices)> createGeometry){
	
	std::vector<VertexPositionNormalTangentColorTextureSkinning2> vertices;
	std::vector<UINT> indices;

	createGeometry(vertices, indices);

	size_t nVerts = vertices.size();

	DirectX::ModelMeshPart* modelMeshPArt(new DirectX::ModelMeshPart());

	modelMeshPArt->indexCount = indices.size();
	modelMeshPArt->startIndex = 0;
	modelMeshPArt->vertexOffset = 0;
	modelMeshPArt->vertexStride = sizeof(VertexPositionNormalTangentColorTextureSkinning2);
	modelMeshPArt->primitiveType = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
	modelMeshPArt->indexFormat = DXGI_FORMAT_R32_UINT;
	modelMeshPArt->vbDecl = std::shared_ptr<std::vector<D3D11_INPUT_ELEMENT_DESC>>(
		new std::vector<D3D11_INPUT_ELEMENT_DESC>(
		&CharacterInputElements[0],
		&CharacterInputElements[sizeof(CharacterInputElements) / sizeof(CharacterInputElements[0])]
		)
		);

	CreateBuffer(device, vertices, D3D11_BIND_VERTEX_BUFFER, modelMeshPArt->vertexBuffer.ReleaseAndGetAddressOf());

	CreateBuffer(device, indices, D3D11_BIND_INDEX_BUFFER, modelMeshPArt->indexBuffer.ReleaseAndGetAddressOf());

	return modelMeshPArt;
}
template<class T> T * create_vector4(T * data, int length)
{
	static T vector[4] = { 0, 0, 0, 0 };

	int i = 0;
	for (; i < length; i++){
		vector[i] = data[i];
	}
	for (; i < 4; i++){
		vector[i] = 0;
	}

	return vector;
}
template<class T> typename T::first_type * extract_first_from_pairs(T * data, int length)
{
	static T::first_type vector[8];

	for (int i = 0; i < length; i++){
		vector[i] = data[i].first;
	}

	return vector;
}
template<class T> typename T::second_type * extract_second_from_pairs(T * data, int length)
{
	static T::second_type vector[8];

	for (int i = 0; i < length; i++){
		vector[i] = data[i].second;
	}

	return vector;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

struct TransformationFrame
{
	TransformationFrame() :NextSibling(), FirstChild(){}
	std::string Name;
	SimpleMath::Matrix Transformation;
	TransformationFrame * NextSibling;
	TransformationFrame * FirstChild;

	std::vector< DirectX::ModelMeshPart* > Meshes;
};

struct CharacterSkelet
{
	CharacterSkelet() :TotalMatrix(), ReservMatrix(){};
	std::map<std::string, unsigned int> FramesNamesIndex;
	unsigned int TotalMatrix;
	unsigned int ReservMatrix;
	std::vector<SimpleMath::Matrix*> Transformation;
	std::vector<SimpleMath::Matrix> BoneOffSetTransformation;
	unsigned int findFrame(const std::string& name)
	{
		auto Iter = FramesNamesIndex.find(name);
		if (FramesNamesIndex.end() != Iter)
		{
			return (*Iter).second;
		}
		else
		{
			unsigned int OldSize = TotalMatrix;
			unsigned int NewSize = ++TotalMatrix;
			FramesNamesIndex.insert(std::pair<std::string, unsigned int>(name, OldSize));
			if (ReservMatrix <= NewSize)
			{
				ReservMatrix += 1024;
				Transformation.reserve(ReservMatrix);
				BoneOffSetTransformation.reserve(ReservMatrix);
			}
			Transformation.resize(NewSize);
			BoneOffSetTransformation.resize(NewSize);
			return OldSize;
		}
	}
};

Animation::~Animation()
{
	delete Impl;
};

void Animation::advanseAnimation(double elapsedTime, SimpleMath::Vector3 & deltaTranslation)
{
};

void Animation::initAnimation(unsigned int size, double rate, double local_duration, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	Impl = new AnimationRep;

	////////////////////////////////////////
	Impl->global_time = 0.0;

	Impl->loop_counter = 0;

	Impl->looped = true;

	Impl->playing = true;
	////////////////////////////////////////
	Impl->local_duration = local_duration;

	Impl->Rate = rate;

	Impl->global_duration = (1.0 / rate) * local_duration;
	////////////////////////////////////////

	Impl->JointsSamples.resize(size);

	CurrentJoints.resize(size);

	for (int i = 0; i < size; i++)
	{
		auto & js = Impl->JointsSamples[i];

		js.set(*(getSkeletMatrix(i)));
		js.getJoint(CurrentJoints[i]);
	}
};

void Animation::setAnimationSpeed(double speed)
{
	Impl->Rate = speed;

	Impl->global_duration = (1.0 / speed) * Impl->local_duration;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
void collectFrames(const aiScene* scene, int level, aiNode * node)
{
	char buffer[1024];
	std::string L;
	for (int i = 0; i < level; i++)
		L.append("-");
	sprintf(buffer, "%s %s \n", L.c_str(), node->mName.C_Str());// , delta.y);

	OutputDebugStringA(buffer);

	for (int i = 0; i < node->mNumChildren; i++)
	{
		collectFrames(scene, level + 1, node->mChildren[i]);
	}
}
*/

void collectFrames(ID3D11Device* device, CharacterSkelet * characterSkelet,  const aiScene* scene, int level, aiNode * node, TransformationFrame * parentFrame)
{
	TransformationFrame * LastChildren = 0;
	for (int i = 0; i < node->mNumChildren; i++)
	{
		//get Childeren node 
		auto ChildrenNode = node->mChildren[i];

		// new Frame
		auto Frame = new TransformationFrame();
		Frame->Transformation = aiMatrixToSimpleMathMatrix(ChildrenNode->mTransformation);
		Frame->Name = ChildrenNode->mName.C_Str();

		//index node matrix
		characterSkelet->Transformation[characterSkelet->findFrame(Frame->Name)] = &(Frame->Transformation);

		//grab asimp mesh
		for (int j = 0; j < ChildrenNode->mNumMeshes; j++){
			auto Mesh = scene->mMeshes[ChildrenNode->mMeshes[j]];

			if (Mesh->GetNumUVChannels() == 0 || Mesh->mNumUVComponents[0] != 2)
				throw "";

			if (!Mesh->mNormals)
				throw "";

			if (!Mesh->mTangents)
				throw "";

			if (!Mesh->mBitangents)
				throw "";

			if (!Mesh->mNumBones)
				throw "";

			auto FrameMesh = CreateModelMeshPart(device, [characterSkelet, Mesh](std::vector<VertexPositionNormalTangentColorTextureSkinning2> & _vertices, std::vector<UINT> & _indices){
				std::map<uint32_t, std::vector<std::pair<uint32_t, float> > > VerticesSkinInfo;

				//proccess bones
				for (int k = 0; k < Mesh->mNumBones; k++)
				{
					auto MeshBone = Mesh->mBones[k];

					//index Bone OffSet matrix( Offset Matrix )
					unsigned int mBoneId = characterSkelet->findFrame(MeshBone->mName.C_Str());
					characterSkelet->BoneOffSetTransformation[mBoneId] = aiMatrixToSimpleMathMatrix(MeshBone->mOffsetMatrix);

					for (int z = 0; z < MeshBone->mNumWeights; z++)
					{
						auto & MeshBoneVertexWeight = MeshBone->mWeights[z];

						//link bone to vertex
						auto pVertexSkinInfo = VerticesSkinInfo.find(MeshBoneVertexWeight.mVertexId);
						if (pVertexSkinInfo == VerticesSkinInfo.end())
						{
							std::vector<std::pair<uint32_t, float> > VertexSkinInfo;
							VertexSkinInfo.push_back(std::pair<uint32_t, float>(mBoneId, MeshBoneVertexWeight.mWeight));
							VerticesSkinInfo.insert(std::pair<uint32_t, std::vector<std::pair<uint32_t, float> > >(MeshBoneVertexWeight.mVertexId, VertexSkinInfo));
						}
						else
						{
							(*pVertexSkinInfo).second.push_back(std::pair<uint32_t, float>(mBoneId, MeshBoneVertexWeight.mWeight));
						}

					}
				}

				//proccess vertex
				for (int k = 0; k < Mesh->mNumVertices; k++){
					auto pVertexSkinInfo = VerticesSkinInfo.find(k);

					if (pVertexSkinInfo == VerticesSkinInfo.end())
						throw "";

					auto & VertexSkinInfo = (*pVertexSkinInfo).second;

					if (VertexSkinInfo.size() > 8)
						throw "";

					auto & MeshVertex = Mesh->mVertices[k];

					auto & MeshUV = Mesh->mTextureCoords[0][k];

					///
					auto & MeshTangent = Mesh->mTangents[k];
					auto & MeshBitangent = Mesh->mBitangents[k];
					auto & MeshNormal = Mesh->mNormals[k];
					///

					uint32_t VertexSkinInfoSize = VertexSkinInfo.size();
					uint32_t * MeshIndices = extract_first_from_pairs(VertexSkinInfo.data(), VertexSkinInfoSize);;
					float * MeshWeights = extract_second_from_pairs(VertexSkinInfo.data(), VertexSkinInfoSize);;

					VertexPositionNormalTangentColorTextureSkinning2 v;

					v.textureCoordinate = SimpleMath::Vector2(MeshUV.x, MeshUV.y);
					v.position = SimpleMath::Vector3(MeshVertex.x, MeshVertex.y, MeshVertex.z);
					v.SetBlendIndices(XMUINT4(create_vector4(MeshIndices, VertexSkinInfoSize)));
					v.SetBlendWeights(SimpleMath::Vector4(create_vector4(MeshWeights, VertexSkinInfoSize)));
					if (VertexSkinInfoSize > 4)
					{
						v.SetBlendIndices2(XMUINT4(create_vector4(MeshIndices + 4, VertexSkinInfoSize - 4)));
						v.SetBlendWeights2(SimpleMath::Vector4(create_vector4(MeshWeights + 4, VertexSkinInfoSize - 4)));
					}
					float _tangent[] = { MeshTangent.x, MeshTangent.y, MeshTangent.z, .0f };
					float _bitangent[] = { MeshBitangent.x, MeshBitangent.y, MeshBitangent.z, .0f };
					float _normal[] = { MeshNormal.x, MeshNormal.y, MeshNormal.z, .0f };
					auto normal = SimpleMath::Vector3(_normal);
					auto tangent = SimpleMath::Vector3(_tangent);
					auto bitangent = SimpleMath::Vector3(_bitangent);
					v.normal = normal;
					v.tangent = SimpleMath::Vector4(_tangent);
					v.tangent.w = (normal.Cross(tangent).Dot(bitangent) < 0.0F) ? -1.0F : 1.0F;
					///

					_vertices.push_back(v);
				}

				//proccess faces
				for (int k = 0; k < Mesh->mNumFaces; k++){
					auto & mFace = Mesh->mFaces[k];

					if (mFace.mNumIndices != 3)
					{
						throw "";
					}

					for (int z = 0; z < 3; z++){
						_indices.push_back(mFace.mIndices[z]);
					};
				}

			});

			Frame->Meshes.push_back(FrameMesh);
		}

		// attach frame to herachy
		if (!LastChildren)
		{
			parentFrame->FirstChild = Frame;
		}
		else
		{
			LastChildren->NextSibling = Frame;
		}
		LastChildren = Frame;

		// deeper and deeper
		collectFrames(device, characterSkelet, scene, level + 1, ChildrenNode, Frame);
	}
}

void disposeFrames(TransformationFrame * Frame)
{
	if (Frame->FirstChild)
		disposeFrames(Frame->FirstChild);
	if (Frame->NextSibling)
		disposeFrames(Frame->NextSibling);

	for (int i = 0; i < Frame->Meshes.size(); i++)
	{
		delete Frame->Meshes[i];
	};

	delete Frame;
}

void calculateFramesTransformations(TransformationFrame * Frame, SimpleMath::Matrix ParentTransformation)
{
	Frame->Transformation = Frame->Transformation * ParentTransformation;
	if (Frame->FirstChild)
		calculateFramesTransformations(Frame->FirstChild, Frame->Transformation);
	if (Frame->NextSibling)
		calculateFramesTransformations(Frame->NextSibling, ParentTransformation);
}

void drawFrames(TransformationFrame * Frame, ID3D11DeviceContext* context, IEffect* effect, ID3D11InputLayout* inputLayout, std::function<void __cdecl()> setCustomState)
{
	if (Frame->FirstChild)
		drawFrames(Frame->FirstChild, context, effect, inputLayout, setCustomState);
	if (Frame->NextSibling)
		drawFrames(Frame->NextSibling, context, effect, inputLayout, setCustomState);

	for (int i = 0; i < Frame->Meshes.size(); i++)
	{
		Frame->Meshes[i]->Draw(context, effect, inputLayout, setCustomState);
	}
}

void advanseAnimation(double elapsedTime, SimpleMath::Vector3 & deltaTranslation, Animation * animation)
{
	animation->advanseAnimation(elapsedTime, deltaTranslation);
}

SimpleMath::Matrix* calculateAnimationPalite(CharacterSkelet * skelet)
{
	static SimpleMath::Matrix palite[1024];
	for (int i = 0; i < skelet->Transformation.size(); i++)
	{
		palite[i] = skelet->BoneOffSetTransformation[i] * (*(skelet->Transformation[i]));
	}
	return palite;
}

SimpleMath::Matrix* GetSkeletonMatrix(CharacterSkelet * skelet, int index)
{
	return skelet->Transformation[index];
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Animation* loadIdleAnimation(std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix);
Animation* loadWalkingAnimation(std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix);

Character::~Character(){
	delete skelet;
	disposeFrames(frame);
};

Character* loadCharacter(ID3D11Device* device, char * file_name)
{
	Assimp::Importer importer;

	// And have it read the given file with some example postprocessing
	// Usually - if speed is not the most important aspect for you - you'll 
	// propably to request more postprocessing than we do in this example.
	//aiProcess_Triangulate
	const aiScene* scene = importer.ReadFile(file_name, aiProcess_ConvertToLeftHanded | aiProcess_CalcTangentSpace);// | aiProcess_Triangulate | aiProcess_FlipUVs );// | aiProcess_Triangulate);// | aiProcess_FlipUVs | aiProcess_GenNormals | aiProcess_CalcTangentSpace);// | aiProcess_MakeLeftHanded);

	auto RootFrame = new TransformationFrame();
	RootFrame->Transformation = aiMatrixToSimpleMathMatrix(scene->mRootNode->mTransformation);
	RootFrame->Name = scene->mRootNode->mName.C_Str();

	auto characterSkelet = new CharacterSkelet();
	//index node matrix
	unsigned int matrixIndex = characterSkelet->findFrame(RootFrame->Name);
	characterSkelet->Transformation[matrixIndex] = &(RootFrame->Transformation);

	collectFrames(device, characterSkelet, scene, 0, scene->mRootNode, RootFrame);

	auto ret = new Character();

	ret->frame = RootFrame;
	ret->skelet = characterSkelet;

	return ret;
}

std::map<AnimationState, Animation *> loadAnimations(CharacterSkelet * characterSkelet)
{
	std::map<AnimationState, Animation *> ret;

	auto walkingAnimation = loadWalkingAnimation(
	characterSkelet->FramesNamesIndex,
	[characterSkelet](unsigned int index){
		return characterSkelet->Transformation[index];
	}
	);
	walkingAnimation->setAnimationSpeed(0.25*0.5);

	auto idleAnimation = loadIdleAnimation(
		characterSkelet->FramesNamesIndex,
		[characterSkelet](unsigned int index){
		return characterSkelet->Transformation[index];
	}
	);

	ret.insert(std::pair<AnimationState, Animation * >(AnimationState::walking, walkingAnimation));
	ret.insert(std::pair<AnimationState, Animation * >(AnimationState::idle, idleAnimation));
	
	return ret;
}