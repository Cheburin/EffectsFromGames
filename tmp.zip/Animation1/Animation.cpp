#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

// #include <assimp/Importer.hpp>      // C++ importer interface
// #include <assimp/scene.h>           // Output data structure
// #include <assimp/postprocess.h>     // Post processing flags

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags

struct Animation2 : public Animation
{
	void advanseAnimation(double time, double elapsedTime, double frame, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
	{
		for (int i = 0; i < Impl->FramesTransformations.size(); i++)
		{
			auto & transform = Impl->FramesTransformations[i];
			auto & pos = Impl->FramesPositions[i];
			auto & scale = Impl->FramesScales[i];
			auto & rot = Impl->FramesRotations[i];
			if (pos.size() || scale.size() || rot.size())
			{
				SimpleMath::Matrix S;
				if (!scale.size())
					S = SimpleMath::Matrix::Identity;
				else
					S = SimpleMath::Matrix::CreateScale(scale[0].scale);
				SimpleMath::Matrix R;
				if (!rot.size())
					R = SimpleMath::Matrix::Identity;
				else
					R = SimpleMath::Matrix::CreateFromQuaternion(SimpleMath::Quaternion(rot[0].rotation));
				SimpleMath::Matrix T;
				if (!pos.size())
					T = SimpleMath::Matrix::Identity;
				else
					T = SimpleMath::Matrix::CreateTranslation(pos[0].position);
				*(getSkeletMatrix(i)) = S*R*T;
			}
			else
			{
				*(getSkeletMatrix(i)) = transform;
			}
		}
	};
};

SimpleMath::Matrix aiMatrixToSimpleMathMatrix(const aiMatrix4x4& aiMe);

void collectBones(aiNode * node, std::vector<SimpleMath::Matrix> * FramesTransformations, std::map<std::string, unsigned int> * FramesNamesIndex)
{
	for (int i = 0; i < node->mNumChildren; i++)
	{
		//get Childeren node 
		auto ChildrenNode = node->mChildren[i];

		auto pFrameIndex = FramesNamesIndex->find(ChildrenNode->mName.C_Str());
		if (pFrameIndex == FramesNamesIndex->end())
		{
			throw "";
		}

		(*FramesTransformations)[pFrameIndex->second] = aiMatrixToSimpleMathMatrix(ChildrenNode->mTransformation);

		// deeper and deeper
		collectBones(ChildrenNode, FramesTransformations, FramesNamesIndex);
	}
}

Animation* loadAnimation(const char * path, std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	Assimp::Importer importer;

	const aiScene* scene = importer.ReadFile(path, aiProcess_ConvertToLeftHanded);

	auto ret = new Animation2();

	ret->initAnimation(FramesNamesIndex.size(), getSkeletMatrix);

	ret->Impl->duration = scene->mAnimations[0]->mDuration;

	{
		auto pFrameIndex = FramesNamesIndex.find(scene->mRootNode->mName.C_Str());
		if (pFrameIndex == FramesNamesIndex.end())
		{
			throw "";
		}
		ret->Impl->FramesTransformations[pFrameIndex->second] = aiMatrixToSimpleMathMatrix(scene->mRootNode->mTransformation);
		collectBones(scene->mRootNode, &(ret->Impl->FramesTransformations), &FramesNamesIndex);
	}

	for (int i = 0; i < scene->mAnimations[0]->mNumChannels; i++)
	{
		auto c = scene->mAnimations[0]->mChannels[i];

		auto f = FramesNamesIndex.find(c->mNodeName.C_Str());
		if (f == FramesNamesIndex.end())
		{
			throw "";
		}
		unsigned int index = f->second;

		for (int j = 0; j < c->mNumScalingKeys; j++)
		{
			auto & sk = c->mScalingKeys[j];

			AScale scale;
			scale.time = sk.mTime;
			scale.scale = SimpleMath::Vector3(sk.mValue.x, sk.mValue.y, sk.mValue.z);

			ret->Impl->FramesScales[index].push_back(scale);
		}

		for (int j = 0; j < c->mNumPositionKeys; j++)
		{
			auto & p = c->mPositionKeys[j];

			APos pos;
			pos.time = p.mTime;
			pos.position = SimpleMath::Vector3(p.mValue.x, p.mValue.y, p.mValue.z);

			ret->Impl->FramesPositions[index].push_back(pos);
		}

		for (int j = 0; j < c->mNumRotationKeys; j++)
		{
			auto & r = c->mRotationKeys[j];

			ARotation rot;
			rot.time = r.mTime;
			rot.rotation = SimpleMath::Vector4(r.mValue.x, r.mValue.y, r.mValue.z, r.mValue.w);

			ret->Impl->FramesRotations[index].push_back(rot);
		}
	}

	return ret;
}

Animation* loadIdleAnimation(std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	return loadAnimation("Media\\Animations\\Idle.dae", FramesNamesIndex, getSkeletMatrix);
}

Animation* loadWalkingAnimation(std::map<std::string, unsigned int> & FramesNamesIndex, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix)
{
	return loadAnimation("Media\\Animations\\Walking.dae", FramesNamesIndex, getSkeletMatrix);
}
