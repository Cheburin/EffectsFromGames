struct AFrameKeysPayload
{
	double time;
	DirectX::XMFLOAT4 payload;
	AFrameKeysPayload(double t, float x, float y, float z, float w)
	{
		time = t;
		payload.x = x;
		payload.y = y;
		payload.z = z;
		payload.w = w;
	}
};
struct AFrameKeys
{
	AFrameKeys()
	{
		resetAllKeyIndex();
	}

	unsigned int currentKeyIndex[3];
	std::vector<AFrameKeysPayload> X[3]; //s r t hips_translation

	void append(unsigned int payloadtype, double time, float x, float y, float z, float w)
	{
		X[payloadtype].push_back(AFrameKeysPayload(time, x, y, z, w));
	}
	void appendScaling(double t, float x, float y, float z)
	{
		append(0, t, x, y, z, 0.0);
	}
	void appendRotation(double t, float x, float y, float z, float w)
	{
		append(1, t, x, y, z, w);
	}
	void appendTranslation(double t, float x, float y, float z)
	{
		append(2, t, x, y, z, 1.0);
	}

	bool IsEmpty()
	{
		return (!X[0].size() && !X[1].size() && !X[2].size());
	}
private:
	struct AKeyPair {
		DirectX::XMFLOAT4 first;
		DirectX::XMFLOAT4 second;
		double t;
	};
	AKeyPair framePayload(unsigned int payload, double time)
	{
		auto & key = currentKeyIndex[payload];
		auto & x = X[payload];
		for (; key < x.size() && x[key].time < time; key++){};
		if (key == x.size())
		{
			throw "framePayload out of duration";
		}
		else if (time != x[key].time)
		{
			key--;
			//interpolation between two frames
			auto & firstKey = x[key];
			auto & secondKey = x[key + 1];
			AKeyPair keys = { firstKey.payload, secondKey.payload, (time - firstKey.time) / (secondKey.time - firstKey.time) };
			return keys;
		}
		else if (time == x[key].time)
		{
			auto & firstKey = x[key];
			AKeyPair keys = { firstKey.payload, DirectX::XMFLOAT4(), 0.0 };
			return keys;
		}
	}
public:
	void resetAllKeyIndex()
	{
		currentKeyIndex[0] = currentKeyIndex[1] = currentKeyIndex[2] = 0;
	}
	SimpleMath::Vector3 scaling(double time)
	{
		AKeyPair keys = framePayload(0, time);
		auto p = SimpleMath::Vector4::Lerp(keys.first, keys.second, keys.t);
		return SimpleMath::Vector3(p.x, p.y, p.z);
	}
	SimpleMath::Quaternion rotation(double time)
	{
		AKeyPair keys = framePayload(1, time);
		auto p = SimpleMath::Quaternion::Lerp(keys.first, keys.second, keys.t);
		return p;
	}
	SimpleMath::Vector3 translation(double time)
	{
		AKeyPair keys = framePayload(2, time);
		auto p = SimpleMath::Vector4::Lerp(keys.first, keys.second, keys.t);
		return SimpleMath::Vector3(p.x, p.y, p.z);
	}
};
struct AnimationRep
{
	std::vector<SimpleMath::Matrix> Transformation;

	double local_duration;

	double global_time;

	double Rate;

	double global_duration;

	bool looped;

	bool playing;

	int loop_counter;

	SimpleMath::Vector3 prev_translation;

	SimpleMath::Vector3 begin_translation;

	SimpleMath::Vector3 end_translation;

	SimpleMath::Vector3 delta_translation;

	std::vector<SimpleMath::Matrix> FramesTransformations;

	std::vector< AFrameKeys > FramesKeys;
};