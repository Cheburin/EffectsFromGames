#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

// #include <assimp/Importer.hpp>      // C++ importer interface
// #include <assimp/scene.h>           // Output data structure
// #include <assimp/postprocess.h>     // Post processing flags

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags


struct AnimationStateMachine
{
	AnimationState state;
	std::map<AnimationState, Animation *> animations;
	CharacterSkelet * skelet;

	~AnimationStateMachine(){
		for (auto p = animations.begin(); p != animations.end(); p++)
			delete (*p).second;
	}
	AnimationStateMachine(std::map<AnimationState, Animation *>  newAnimations, CharacterSkelet * newSkelet){
		state = AnimationState::idle;
		animations = newAnimations;
		skelet = newSkelet;
	}
	void exec(AnimationState newState, double newElipsedTime, SimpleMath::Vector3 & deltaTranslation){
		//if (state == AnimationState::idle && newState == AnimationState::walking)
		{
			auto & animation = animations[state];

			advanseAnimation(newElipsedTime, deltaTranslation, animation);

			for (int i = 0; i < animation->CurrentJoints.size(); i++)
			{
				auto & cj = animation->CurrentJoints[i];

				auto _S = SimpleMath::Matrix::CreateScale(cj[0].x, cj[0].y, cj[0].z);
				auto _Q = SimpleMath::Matrix::CreateFromQuaternion(SimpleMath::Quaternion(cj[1].x, cj[1].y, cj[1].z, cj[1].w));
				auto _T = SimpleMath::Matrix::CreateTranslation(cj[2].x, cj[2].y, cj[2].z);

				(*GetSkeletonMatrix(skelet, i)) = _S * _Q * _T;
			}
			state = newState;
		}
	}
};

AnimationStateMachine * makeAnimationStateMachine(std::map<AnimationState, Animation *> newAnimations, CharacterSkelet * skelet)
{
	return new AnimationStateMachine(newAnimations, skelet);
}

void animationStateMachineExec(AnimationStateMachine* stateMachine, AnimationState newState, double newElipsedTime, SimpleMath::Vector3 & deltaTranslation)
{
	stateMachine->exec(newState, newElipsedTime, deltaTranslation);
}

void disposeAnimationStateMachine(AnimationStateMachine* stateMachine)
{
	delete stateMachine;
}