#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

// #include <assimp/Importer.hpp>      // C++ importer interface
// #include <assimp/scene.h>           // Output data structure
// #include <assimp/postprocess.h>     // Post processing flags

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags

SimpleMath::Matrix* GetSkeletonMatrix(CharacterSkelet * skelet, int index);

IAnimationGraph::~IAnimationGraph()
{

}

struct AnimationGraph : IAnimationGraph
{
	AnimationState state;
	std::map<AnimationState, Animation *> animations;
	CharacterSkelet * skelet;

	~AnimationGraph(){
		for (auto p = animations.begin(); p != animations.end(); p++)
			delete (*p).second;
	}
	AnimationGraph(std::map<AnimationState, Animation *>  newAnimations, CharacterSkelet * newSkelet){
		state = AnimationState::idle;
		animations = newAnimations;
		skelet = newSkelet;
	}
	void advanse(double newElipsedTime, SimpleMath::Vector3 & deltaTranslation){
		auto & animation = animations[state];

		animation->advanse(newElipsedTime, deltaTranslation);

		for (int i = 0; i < animation->CurrentJoints.size(); i++)
		{
			auto & cj = animation->CurrentJoints[i];

			auto _S = SimpleMath::Matrix::CreateScale(cj[0].x, cj[0].y, cj[0].z);
			auto _Q = SimpleMath::Matrix::CreateFromQuaternion(SimpleMath::Quaternion(cj[1].x, cj[1].y, cj[1].z, cj[1].w));
			auto _T = SimpleMath::Matrix::CreateTranslation(cj[2].x, cj[2].y, cj[2].z);

			(*GetSkeletonMatrix(skelet, i)) = _S * _Q * _T;
		}

		checkStatus();
	}
	void checkStatus(){
		auto & animation = animations[state];

		if (!animation->isPlaying())
		{
			if (state == AnimationState::idle_to_walking)
			{
				state = AnimationState::walking;
			}
			if (state == AnimationState::walking_to_idle)
			{
				state = AnimationState::idle;
			}
		}
	}
	void setState(AnimationState newState){
		if (state == AnimationState::idle && newState == AnimationState::walking)
		{
			animations[AnimationState::idle]->reset();
			animations[AnimationState::idle_to_walking]->reset();
			state = AnimationState::idle_to_walking;
		}
		if (state == AnimationState::walking && newState == AnimationState::idle)
		{
			animations[AnimationState::walking]->reset();
			animations[AnimationState::walking_to_idle]->reset();
			state = AnimationState::walking_to_idle;
		}
	}
	AnimationState getState(){
		return state;
	}
};

IAnimationGraph * makeAnimationGraph(std::map<AnimationState, Animation *> newAnimations, CharacterSkelet * skelet)
{
	return new AnimationGraph(newAnimations, skelet);
}

void disposeAnimationGraph(IAnimationGraph* gr)
{
	delete gr;
}