#include "main.h"
#include "AnimationImpl.h"
#include <fstream>

#include <locale>
#include <codecvt>
#include <string>
#include <array>
#include <map>
#include <locale> 

#include <assimp/Importer.hpp>      // C++ importer interface
#include <assimp/scene.h>           // Output data structure
#include <assimp/postprocess.h>     // Post processing flags

struct AnimationLinearTransition : Animation
{
	AnimationRep3* Impl;

	AnimationLinearTransition()
	{
		Impl = new AnimationRep3();
	}

	~AnimationLinearTransition()
	{
		delete Impl;
	};

	void setRate(double speed)
	{

	}

	bool isPlaying()
	{
		return Impl->playing;
	}

	void reset()
	{
		Impl->global_time = .0;

		Impl->playing = true;
	}

	void init(Animation* _animation1, Animation* _animation2, double local_duration, std::function<double __cdecl(double, double)> _BlendFunction, std::function<std::pair<SimpleMath::Vector3, SimpleMath::Vector3> __cdecl(double, Animation*, Animation*)> _AdvanseFunction)
	{
		Impl->Rate = 1.0;

		Impl->local_duration = local_duration;

		Impl->global_duration = (1.0) * local_duration;

		Impl->animation1 = _animation1;

		Impl->animation2 = _animation2;

		Impl->BlendFunction = _BlendFunction;

		Impl->AdvanseFunction = _AdvanseFunction;

		auto size = Impl->animation1->CurrentJoints.size();

		CurrentJoints.resize(size);

		for (int i = 0; i < size; i++)
			CurrentJoints[i] = Impl->animation1->CurrentJoints[i];
	}

	void advanse(double elapsedTime, SimpleMath::Vector3 & deltaTranslation)
	{
		auto delta = Impl->AdvanseFunction(elapsedTime, Impl->animation1, Impl->animation2);

		double t = Impl->BlendFunction(Impl->global_time, Impl->global_duration);

		auto size = CurrentJoints.size();

		for (int i = 0; i < size; i++)
		{
			auto & joint1 = Impl->animation1->CurrentJoints[i];
			auto & joint2 = Impl->animation2->CurrentJoints[i];

			auto & joint = CurrentJoints[i];

			joint[0] = SimpleMath::Vector4::Lerp(joint1[0], joint2[0], t);
			joint[1] = SimpleMath::Quaternion::Lerp(joint1[1], joint2[1], t);
			joint[2] = SimpleMath::Vector4::Lerp(joint1[2], joint2[2], t);
			deltaTranslation = SimpleMath::Vector3::Lerp(delta.first, delta.second, t);
			//deltaTranslation = delta.second;
		}

		if (Impl->playing){
			Impl->global_time += elapsedTime;
			if (Impl->global_time > Impl->global_duration){
				Impl->global_time -= elapsedTime;
				Impl->playing = false;
			}
		}
	}
};

Animation* makeAnimationTransition(Animation* _animation1, Animation* _animation2, double local_duration, std::function<double __cdecl(double, double)> _BlendFunction, std::function<std::pair<SimpleMath::Vector3, SimpleMath::Vector3> __cdecl(double, Animation*, Animation*)> _AdvanseFunction)
{
	auto ret = new AnimationLinearTransition();

	ret->init(_animation1, _animation2, local_duration, _BlendFunction, _AdvanseFunction);

	return ret;
}
