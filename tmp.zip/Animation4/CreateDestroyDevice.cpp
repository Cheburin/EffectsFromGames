#include "main.h"

#include "DXUTgui.h"
#include "SDKmisc.h"

HWND DXUTgetWindow();

GraphicResources * G;

SceneState scene_state;
PostProccessState post_proccess_state;
BoneToModelPalite bone_to_model_palite;

std::unique_ptr<Keyboard> _keyboard;
std::unique_ptr<Mouse> _mouse;

CDXUTDialogResourceManager          g_DialogResourceManager;
CDXUTTextHelper*                    g_pTxtHelper = NULL;

float ViewPortWidth;

float ViewPortHeight;

#include <codecvt>

Character * Eve;

IAnimationGraph * EveAnimationGraph;

extern D3D11_INPUT_ELEMENT_DESC CharacterInputElements[9];

void CreateInputLayoutForCharacter(_In_ ID3D11Device* device, IEffect* effect, _Outptr_ ID3D11InputLayout** pInputLayout)
{
	assert(pInputLayout != 0);

	void const* shaderByteCode;
	size_t byteCodeLength;

	effect->GetVertexShaderBytecode(&shaderByteCode, &byteCodeLength);

	device->CreateInputLayout(CharacterInputElements,
		sizeof(CharacterInputElements) / sizeof(CharacterInputElements[0]),
		shaderByteCode, byteCodeLength,
		pInputLayout
	);
}

HRESULT CALLBACK OnD3D11CreateDevice(ID3D11Device* device, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc,
	void* pUserContext)
{
	HRESULT hr;

	ID3D11DeviceContext* context = DXUTGetD3D11DeviceContext();

	G = new GraphicResources();

	G->render_states = std::make_unique<CommonStates>(device);

	G->scene_constant_buffer = std::make_unique<ConstantBuffer<SceneState> >(device);
	G->post_proccess_constant_buffer = std::make_unique<ConstantBuffer<PostProccessState> >(device);
	G->bone_to_model_constant_buffer = std::make_unique<ConstantBuffer<BoneToModelPalite> >(device);

	HWND hwnd = DXUTgetWindow();

	_keyboard = std::make_unique<Keyboard>();
	_mouse = std::make_unique<Mouse>();
	_mouse->SetWindow(hwnd);

	g_DialogResourceManager.OnD3D11CreateDevice(device, context);
	g_pTxtHelper = new CDXUTTextHelper(device, context, &g_DialogResourceManager, 15);

	//effects SINGLE FILE FOR ALL EFFECTS
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"GROUND_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"GROUND_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"GROUND_PS", L"ps_5_0" };

		G->ground_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"BOX_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"BOX_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"BOX_PS", L"ps_5_0" };

		G->box_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"BOX_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"BOX_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"BOX_GLOW_PS", L"ps_5_0" };

		G->box_glow_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"BLUR_HORIZONTAL_PS", L"ps_5_0" };

		G->blur_horizontal_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"BLUR_VERTICAL_PS", L"ps_5_0" };

		G->blur_vertical_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"SKY_VS", L"vs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"SKY_PS", L"ps_5_0" };

		G->sky_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"WINSTONS_BARRIER_VS", L"vs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"WINSTONS_BARRIER_PS", L"ps_5_0" };

		G->winstons_barrier_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"POST_PROCCESS_PS", L"ps_5_0" };

		G->post_proccess_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_VS", L"vs_5_0" };
		shaderDef[L"GS"] = { L"ModelVS.hlsl", L"POST_PROCCESS_GS", L"gs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"COPY_PS", L"ps_5_0" };

		G->copy_effect = createHlslEffect(device, shaderDef);
	}
	{
		std::map<const WCHAR*, EffectShaderFileDef> shaderDef;
		shaderDef[L"VS"] = { L"ModelVS.hlsl", L"EVE_VS", L"vs_5_0" };
		shaderDef[L"PS"] = { L"ModelPS.hlsl", L"EVE_PS", L"ps_5_0" };

		G->eve_effect = createHlslEffect(device, shaderDef);
	}
	//textures
	{
		hr = D3DX11CreateShaderResourceViewFromFile(device, L"Media\\Textures\\meadow.dds", NULL, NULL, G->sky_cube_texture.ReleaseAndGetAddressOf(), NULL);
		hr = D3DX11CreateShaderResourceViewFromFile(device, L"Media\\Textures\\dirt.dds", NULL, NULL, G->ground_texture.ReleaseAndGetAddressOf(), NULL);
		hr = D3DX11CreateShaderResourceViewFromFile(device, L"Media\\Textures\\normal.dds", NULL, NULL, G->ground_normal_texture.ReleaseAndGetAddressOf(), NULL);
		hr = D3DX11CreateShaderResourceViewFromFile(device, L"Media\\Textures\\hexagon01.png", NULL, NULL, G->hexagon_texture.ReleaseAndGetAddressOf(), NULL);
		hr = D3DX11CreateShaderResourceViewFromFile(device, L"Media\\Characters\\textures\\SpacePirate_diffuse.png", NULL, NULL, G->eve_d_texture.ReleaseAndGetAddressOf(), NULL);
		hr = D3DX11CreateShaderResourceViewFromFile(device, L"Media\\Characters\\textures\\SpacePirate_normal.png", NULL, NULL, G->eve_n_texture.ReleaseAndGetAddressOf(), NULL);
	}

	//models
	{
		G->sphere_model = GeometricPrimitive::CreateSphere(context, 1, 32, false, false);
		G->sphere_model->CreateInputLayout(G->sky_effect.get(), G->sphere_input_layout.ReleaseAndGetAddressOf());

		Eve = loadCharacter(device, "Media\\Characters\\eve_j_gonzales.dae");

		EveAnimationGraph = makeAnimationGraph(loadAnimations(Eve->skelet), Eve->skelet);

		CreateInputLayoutForCharacter(device, G->eve_effect.get(), G->eve_input_layout.GetAddressOf());
	}

	//common layout
	{
	}

	//set states 
	{
		post_proccess_state.ScanWidth = 5.0f;
	}

	//RStates
	{
		D3D11_BLEND_DESC desc;
		ZeroMemory(&desc, sizeof(desc));

		desc.RenderTarget[0].BlendEnable = true;

		desc.RenderTarget[0].SrcBlend = desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
		desc.RenderTarget[0].DestBlend = desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
		desc.RenderTarget[0].BlendOp = desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;

		desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

		HRESULT hr = device->CreateBlendState(&desc, G->AdditiveBlend.ReleaseAndGetAddressOf());
	}

	return S_OK;
}

//--------------------------------------------------------------------------------------
// Release D3D11 resources created in OnD3D11CreateDevice 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D11DestroyDevice(void* pUserContext)
{
	delete g_pTxtHelper;

	disposeAnimationGraph(EveAnimationGraph);

	delete Eve;

	g_DialogResourceManager.OnD3D11DestroyDevice();

	_mouse = 0;

	_keyboard = 0;

	delete G;
}
