#include "GeometricPrimitive.h"
#include "Effects.h"
#include "DirectXHelpers.h"
#include "Model.h"
#include "CommonStates.h"
#include "Keyboard.h"
#include "Mouse.h"
#include "SimpleMath.h"

#include "DirectXMath.h"

#include "DXUT.h"

#include <wrl.h>

#include <map>
#include <algorithm>
#include <array>
#include <memory>
#include <assert.h>
#include <malloc.h>
#include <Exception>

#include "ConstantBuffer.h"

#include "AppBuffers.h"

using namespace DirectX;

struct EffectShaderFileDef{
	WCHAR * name;
	WCHAR * entry_point;
	WCHAR * shader_ver;
};
class IPostProcess
{
public:
	virtual ~IPostProcess() { }

	virtual void __cdecl Process(_In_ ID3D11DeviceContext* deviceContext, _In_opt_ std::function<void __cdecl()> setCustomState = nullptr) = 0;
};

inline ID3D11RenderTargetView** renderTargetViewToArray(ID3D11RenderTargetView* rtv1, ID3D11RenderTargetView* rtv2 = 0, ID3D11RenderTargetView* rtv3 = 0){
	static ID3D11RenderTargetView* rtvs[10];
	rtvs[0] = rtv1;
	rtvs[1] = rtv2;
	rtvs[2] = rtv3;
	return rtvs;
};
inline ID3D11ShaderResourceView** shaderResourceViewToArray(ID3D11ShaderResourceView* rtv1, ID3D11ShaderResourceView* rtv2 = 0, ID3D11ShaderResourceView* rtv3 = 0, ID3D11ShaderResourceView* rtv4 = 0, ID3D11ShaderResourceView* rtv5 = 0){
	static ID3D11ShaderResourceView* srvs[10];
	srvs[0] = rtv1;
	srvs[1] = rtv2;
	srvs[2] = rtv3;
	srvs[3] = rtv4;
	srvs[4] = rtv5;
	return srvs;
};
inline ID3D11Buffer** constantBuffersToArray(ID3D11Buffer* c1, ID3D11Buffer* c2){
	static ID3D11Buffer* cbs[10];
	cbs[0] = c1;
	cbs[1] = c2;
	return cbs;
};
inline ID3D11Buffer** constantBuffersToArray(DirectX::ConstantBuffer<SceneState> &cb){
	static ID3D11Buffer* cbs[10];
	cbs[0] = cb.GetBuffer();
	return cbs;
};
inline ID3D11Buffer** constantBuffersToArray(DirectX::ConstantBuffer<PostProccessState> &cb){
	static ID3D11Buffer* cbs[10];
	cbs[0] = cb.GetBuffer();
	return cbs;
};
inline ID3D11Buffer** constantBuffersToArray(DirectX::ConstantBuffer<BoneToModelPalite> &cb){
	static ID3D11Buffer* cbs[10];
	cbs[0] = cb.GetBuffer();
	return cbs;
};
inline ID3D11SamplerState** samplerStateToArray(ID3D11SamplerState* ss1, ID3D11SamplerState* ss2 = 0){
	static ID3D11SamplerState* sss[10];
	sss[0] = ss1;
	sss[1] = ss2;
	return sss;
};

namespace Camera{
	void CALLBACK OnFrameMove(double fTime, float fElapsedTime, void* pUserContext);
}
std::unique_ptr<DirectX::IEffect> createHlslEffect(ID3D11Device* device, std::map<const WCHAR*, EffectShaderFileDef>& fileDef);

class GraphicResources {
public:
	std::unique_ptr<CommonStates> render_states;

	std::unique_ptr<DirectX::IEffect> eve_effect;

	std::unique_ptr<DirectX::IEffect> sky_effect;

	std::unique_ptr<DirectX::IEffect> winstons_barrier_effect;

	std::unique_ptr<DirectX::IEffect> box_effect;

	std::unique_ptr<DirectX::IEffect> box_glow_effect;

	std::unique_ptr<DirectX::IEffect> blur_horizontal_effect;

	std::unique_ptr<DirectX::IEffect> blur_vertical_effect;

	std::unique_ptr<DirectX::IEffect> post_proccess_effect;

	std::unique_ptr<DirectX::IEffect> ground_effect;

	std::unique_ptr<DirectX::ConstantBuffer<SceneState> > scene_constant_buffer;

	std::unique_ptr<DirectX::ConstantBuffer<PostProccessState> > post_proccess_constant_buffer;

	std::unique_ptr<ConstantBuffer<BoneToModelPalite> > bone_to_model_constant_buffer;

	std::unique_ptr<GeometricPrimitive> sphere_model;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> sky_cube_texture;

	Microsoft::WRL::ComPtr<ID3D11InputLayout> sphere_input_layout;

	Microsoft::WRL::ComPtr<ID3D11InputLayout> eve_input_layout;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> ground_texture;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> ground_normal_texture;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> hexagon_texture;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> eve_d_texture;

	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> eve_n_texture;

	std::unique_ptr<DirectX::IEffect> copy_effect;

	Microsoft::WRL::ComPtr<ID3D11BlendState> AdditiveBlend;
};

class SwapChainGraphicResources {
public:
	Microsoft::WRL::ComPtr<ID3D11Texture2D> T_glowObjects;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> SR_glowObjects;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> RT_glowObjects;

	Microsoft::WRL::ComPtr<ID3D11Texture2D> T_scene;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> SR_scene;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> RT_scene;

	Microsoft::WRL::ComPtr<ID3D11Texture2D> T_glowBlurObjects;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> SR_glowBlurObjects;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> RT_glowBlurObjects;

	Microsoft::WRL::ComPtr<ID3D11Texture2D> T_glowBlurObjects1;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> SR_glowBlurObjects1;
	Microsoft::WRL::ComPtr<ID3D11RenderTargetView> RT_glowBlurObjects1;

	Microsoft::WRL::ComPtr<ID3D11Texture2D> T_depth;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> SR_depth;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> DS_depth;

	Microsoft::WRL::ComPtr<ID3D11Texture2D> T_depth1;
	Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> SR_depth1;
	Microsoft::WRL::ComPtr<ID3D11DepthStencilView> DS_depth1;
};

struct TransformationFrame;
struct CharacterSkelet;
struct AnimationRep;
struct AnimationStateMachine;

struct Animation
{
	virtual ~Animation();
	virtual void advanseAnimation(double elapsedTime, SimpleMath::Vector3 & deltaTranslation, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix);
	virtual void initAnimation(unsigned int size, double rate, double local_duration, std::function<SimpleMath::Matrix * __cdecl(unsigned int index)> getSkeletMatrix);
	virtual void setAnimationSpeed(double speed);
	virtual void resetFramesKeys();
	AnimationRep* Impl;
};

struct Character
{
	TransformationFrame * frame;
	CharacterSkelet * skelet;

	~Character();
};

enum AnimationState
{
	idle,
	walking
};

Character* loadCharacter(ID3D11Device* device, char * file_name);
std::map<AnimationState, Animation *> loadAnimations(CharacterSkelet * characterSkelet);
AnimationStateMachine * makeAnimationStateMachine(std::map<AnimationState, Animation *> newAnimations, CharacterSkelet * skelet);
void advanseAnimation(double elapsedTime, SimpleMath::Vector3 & deltaTranslation, CharacterSkelet * skelet, Animation * animation);
void calculateFramesTransformations(TransformationFrame * Frame, SimpleMath::Matrix ParentTransformation);
SimpleMath::Matrix* calculateAnimationPalite(CharacterSkelet * skelet);
void drawFrames(TransformationFrame * Frame, ID3D11DeviceContext* context, IEffect* effect, ID3D11InputLayout* inputLayout, std::function<void __cdecl()> setCustomState);
void animationStateMachineExec(AnimationStateMachine* stateMachine, AnimationState newState, double newElipsedTime, SimpleMath::Vector3 & deltaTranslation);
void disposeAnimationStateMachine(AnimationStateMachine* stateMachine);