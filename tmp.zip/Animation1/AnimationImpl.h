struct AScale
{
	double time;
	DirectX::XMFLOAT3 scale;
};
struct APos
{
	double time;
	DirectX::XMFLOAT3 position;
};
struct ARotation
{
	double time;
	DirectX::XMFLOAT4 rotation;
};
struct AnimationRep
{
	std::vector<SimpleMath::Matrix> Transformation;

	double duration;

	std::vector<SimpleMath::Matrix> FramesTransformations;

	std::vector<std::vector<AScale> > FramesScales;

	std::vector<std::vector<APos> > FramesPositions;

	std::vector<std::vector<ARotation> > FramesRotations;
};